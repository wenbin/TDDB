/*
 * This file is a part of the RMI Plugin for Eclipse tutorials.
 * Copyright (C) 2002-7 Genady Beryozkin
 */
package demo.rmi.print.server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashSet;

import demo.rmi.print.common.RemotePrinter;

/**
 * This is a simulation of a printer server. Note that in real
 * application, server level synchronization may be needed.
 * 
 * @author Genady Beryozkin, rmi-info@genady.net
 */
public class RemotePrinterImpl extends UnicastRemoteObject implements RemotePrinter {

	/**
	 * Collection of all incomplete printing jobs 
	 */
    private HashSet incompleteJobs = new HashSet();
    
    /**
     * Counter that is used to generate job ids.
     */
    private int jobCounter;
    
    /**
     * The printer name
     */
    private String name;


    /**
	 * Constant serialVersionUID is needed for serialization interoperability
	 * if this file is compiled with different compilers.
	 */
	private static final long serialVersionUID = 5885886202424414094L;

	/** 
	 * Default constructor that only copies the printer's name. 
	 * The super constructor also exports the remote object.
	 */
    public RemotePrinterImpl(String name) throws RemoteException {
    	this.name = name;
    }

    /**
     * Submit a new job. Every second job completes immediately,
     * and every other job is recorded as incomplete.
     * 
     * @param text the text to be printed 
     * @return the job id.
     * @throws RemoteException
     */
    public int submitJob(String text) throws RemoteException {
        int jobID = jobCounter++;
        if (jobID % 2 == 0) {
            incompleteJobs.add(new Integer(jobID));
        }
        System.out.println(name + ": Job #" + jobID + " was submitted");
        return jobID;
    }

    /** 
     * Returns whether the job is complete. Dumb implementation
     * marks the job as complete after this call.
     * 
     * @param id the job id.
     * @return true if the job is marked as complete.
     * @throws RemoteException
     */
    public boolean isComplete(int id) throws RemoteException {
        Integer jobID = new Integer(id);
        if (incompleteJobs.remove(jobID)) {
        	return false;
        } else {
        	return id < jobCounter;
        }
    }

    /**
     * Randomly return one of three possible status strings:
     * <code>"Ready"</code>, <code>"Error"</code> or <code>"Unknown"</code>.
     * The status does not affect the actual server behavior.
     * 
     * @throws RemoteException
     */
    public String getPrinterStatus() throws RemoteException {
        switch (Math.abs((int)System.currentTimeMillis()) % 3) {
            case 0: return "Ready";
            case 1: return "Error";
            default: return "Unknown";
        }
    }
    
    /**
     * This convenience method registers 3 printers named 
     * "printer1", "printer2" and "printer3" in the default local registry.
     * 
     * The application never quits, it must be killed manually.
     * (The application will quit if there are no more references to the printers
     * either in the registry or on client side).
     */
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind("printer1", new RemotePrinterImpl("printer1"));
            registry.rebind("printer2", new RemotePrinterImpl("printer2"));
            registry.rebind("printer3", new RemotePrinterImpl("printer3"));
        } catch (RemoteException e) {
            System.err.println("Something wrong happended on the remote end");
            e.printStackTrace();
            System.exit(-1); // can't just return, rmi threads may not exit
        }
        System.out.println("The print server is ready");
    }
}
