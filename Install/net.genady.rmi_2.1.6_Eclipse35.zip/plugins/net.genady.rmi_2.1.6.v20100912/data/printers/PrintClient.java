/*
 * This file is a part of the RMI Plugin for Eclipse tutorials.
 * Copyright (C) 2002-7 Genady Beryozkin
 */
package demo.rmi.print.client;

import java.rmi.RMISecurityManager;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import demo.rmi.print.common.RemotePrinter;

/**
 * This is a simple print client.
 * 
 * @author Genady Beryozkin, rmi-info@genady.net
 */
public class PrintClient {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java " + PrintClient.class + " <registry name>");
            return;
        }
        System.setSecurityManager(new RMISecurityManager());
        try {
            Registry registry = LocateRegistry.getRegistry(args[0]);
            int selectedPrinter = (int)(System.currentTimeMillis() % 3) + 1;
            RemotePrinter printer = (RemotePrinter)registry.lookup("printer" + 
            		selectedPrinter);
            int jobID = printer.submitJob("This is my print job");
            System.out.println("Submitted print job (id=" + jobID + ") to printer" 
            		+ selectedPrinter);
            while (!printer.isComplete(jobID)) {
                System.out.println("Print job " + jobID + " is awaiting completion.");
                System.out.println("Printer status: " + printer.getPrinterStatus());
            }
            System.out.println("Done printing");
        } catch (Exception e) {
            // Something wrong here
            e.printStackTrace();
        }
    }
}
