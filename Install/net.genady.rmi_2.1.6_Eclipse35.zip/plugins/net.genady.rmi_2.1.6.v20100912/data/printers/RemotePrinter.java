/*
 * This file is a part of the RMI Plugin for Eclipse tutorials.
 * Copyright (C) 2002-7 Genady Beryozkin
 */
package demo.rmi.print.common;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * This is the generic remote printer inteface. It has methods to
 * submit print jobs, query their status. Querying the printer status
 * is also possible using the {@link #getPrinterStatus()} method.
 * 
 * @author Genady Beryozkin, rmi-info@genady.net
 */
public interface RemotePrinter extends Remote {

    /**
     * Submit a new print job.
     * 
     * @param text the text to be printed
     * @return the id of the print job.
     * 
     * @throws RemoteException if a remote exception occurs
     */
    public int submitJob(String text) throws RemoteException;
    
    /**
     * Check the job's completion status.
     * 
     * @param id the job id
     * @return <code>true</code> if the job is complete and 
     * <code>false</code> otherwise.
     * 
     * @throws RemoteException if a remote exception occurs
     */
    public boolean isComplete(int id) throws RemoteException;
    
    /**
     * Queries the printer status.
     * 
     * @return printer status in a human readable form. 
     * @throws RemoteException if a remote exception occurs
     */
    public String getPrinterStatus() throws RemoteException;
}