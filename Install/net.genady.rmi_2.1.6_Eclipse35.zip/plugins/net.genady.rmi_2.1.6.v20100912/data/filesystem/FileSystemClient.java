/*
 * This file is a part of the RMI Plugin for Eclipse tutorials.
 * Copyright (C) 2002-7 Genady Beryozkin
 * 
 * You are free to modify this file, as long as you leave
 * the following copyright:
 * 
 * This file is based on the Remote File System example of
 * the RMI Plug-in for Eclipse. The original code is 
 * Copyright (C) 2002-7 Genady Beryozkin
 */
package demo.rmi.filesystem.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PushbackInputStream;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;

import demo.rmi.filesystem.common.IRemoteFile;
import demo.rmi.filesystem.common.IRemoteFileSystem;
import demo.rmi.filesystem.common.IRemoteFilenameFilter;
import demo.rmi.filesystem.common.IRemoteInputStream;


/**
 * A sample file system client. It performs several manipulations on the remote
 * file system. The client can be used with Windows or Unix based server, and
 * it tries to locate the WINDOWS directory (or the /usr directory) on the server 
 * and work inside that directory. 
 * It is possible to operate on the entire file system, but then
 * this example would take many minutes (~20 mins) to complete, depending
 * on the number of files on the server.
 *  
 * See the methods of this class for more information.
 * 
 * @author Genady Beryozkin, rmi-info@genady.net
 */
public class FileSystemClient {

	public static void main(String[] args) {
		System.setSecurityManager(new RMISecurityManager());
		
		String where = "rmi://localhost/FileServer";
		if (args.length == 1) {
			where = args[0];
		}

		try {
			IRemoteFileSystem fs = (IRemoteFileSystem) Naming.lookup(where);
			System.out.println("Connected to remote machine " + fs.getHost());
			IRemoteFile sampleDir = getSampleOSDir(fs);
			countFilesAndDirs(sampleDir);
			findWindowsDlls(sampleDir);
			findSemiPalindromes(sampleDir, false);
			findSemiPalindromes(sampleDir, true);
			printTextFiles(sampleDir);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Return the "working" directory that will be used as a root for
	 * all other methods. It is wither "WINDOWS", "WINNT", or "/usr".
	 */
	private static IRemoteFile getSampleOSDir(IRemoteFileSystem fs) throws RemoteException {
		String winDirs[] = new String[]{"WINNT", "WINDOWS"}; 
		IRemoteFile roots[] = fs.getRoots();
		for (int i = 0; i < roots.length; i++) {
			for (int j = 0; j < winDirs.length; j++) {
				IRemoteFile win = roots[i].getChild(winDirs[j]);
				if (win.exists() && win.isDirectory() && win.canRead()) {
					return win;
				}
			}
		}
		IRemoteFile usr = fs.getRemoteFile("/usr");
		if (usr.exists() && usr.isDirectory() && usr.canRead()) {
			return usr;
		}
		return null;
	}
	
	/**
	 * Count the number of files and directories under the provided
	 * root.
	 * @param root the root at which the scan is performed.
	 */
	private static void countFilesAndDirs(IRemoteFile root) throws RemoteException {
		System.out.println("Starting files and dirs count of " + root.getPath()
				+ " :");
		int dirCount = 0;
		int fileCount = 0;
		LinkedList<IRemoteFile> dirs = new LinkedList<IRemoteFile>();
		dirs.add(root);
		while (!dirs.isEmpty()) {
			IRemoteFile dir = dirs.removeLast();
			dirCount ++;
			int numFiles = dir.list().length;
			IRemoteFile[] subDirs = dir.listRemoteDirectories();
			dirs.addAll(Arrays.asList(subDirs));
			
			fileCount += (numFiles - subDirs.length);
		}
		System.out.println("Found " + dirCount + " directories and " + fileCount + " files\n\n");
	}
	
	/**
	 * Scan the directory tree for files that end with .dll.
	 * The (?i) prefix is used to make the regular expression case insensitive.
	 */
	private static void findWindowsDlls(IRemoteFile root) throws RemoteException {
		System.out.println("Scanning remote machine for .DLL files");
		scanByExtension(root, "(?i)dll");
		System.out.println("\n\n");
	}
	
	/**
	 * The actual implementation of {@link #findWindowsDlls(IRemoteFile)}
	 */
	private static void scanByExtension(IRemoteFile parent, String ext) throws RemoteException {
		long totalSize = 0;
		long numFiles = 0;
		IRemoteFile mostRecent = null;
		long lastTimeStamp = -1;
		
		LinkedList<IRemoteFile> dirs = new LinkedList<IRemoteFile>();
		dirs.add(parent);
		while (!dirs.isEmpty()) {
			IRemoteFile dir = dirs.removeLast();
			IRemoteFile files[] = dir.listByRegex(".*\\." + ext, false);
			for (int i = 0; i < files.length; i++) {
				numFiles++;
				totalSize += files[i].length();
				long ts = files[i].lastModified();
				if (ts > lastTimeStamp) {
					mostRecent = files[i];
				}
			}
			
			dirs.addAll(Arrays.asList(dir.listRemoteDirectories()));
		}
		System.out.println("Total number of files: " + numFiles);
		System.out.println("Total file size: " + totalSize);
		if (mostRecent != null) {
			System.out.println("Most recent file is : " + mostRecent.getAbsolutePath());
			System.out.println("Most recent file's modification date is : " + new Date(lastTimeStamp));
		}
	}
	
	/**
	 * A filter that accepts what can be called a "semi-palindromic" file names.
	 * A semi-palindrome is a palindrome limited to the outermost 2 characters.
	 * Semi-palindromes are more frequent than "full" palindromes.
	 * 
	 * @see FileSystemClient#findSemiPalindromes(IRemoteFile, boolean)
	 */
	private static class SemiPalindromeFilter implements IRemoteFilenameFilter, Serializable {
		private static final long serialVersionUID = 4128871701587623050L;
		
		public boolean accept(IRemoteFile dir, String name) {
			return isSemiPalindrom(name);
		}

		private boolean isSemiPalindrom(String name) {
			if (name.length() < 2) {
				return false;
			}
			for (int i = 0; (i < name.length() / 2) && (i < 2); i++) {
				if (name.charAt(i) != name.charAt(name.length() - i - 1)) {
					return false;
				}
			}
			return true;
		}
	}
	
	/**
	 * Find all semi-palindromic file names. It is of course possible to search
	 * for "full" palindromes but they are rare as filenames.
	 * 
	 * If <code>export</code> is true, the method will export the file filter object
	 * and the server will make callbacks to our JVM when it calls 
	 * {@link SemiPalindromeFilter#accept(IRemoteFile, String)}.
	 * If <code>export</code> is false, then the {@link SemiPalindromeFilter} class
	 * itself (and not it's stub) will be loaded by the server and executed on
	 * the server.
	 * 
	 * @param root
	 * @param export
	 * @throws RemoteException
	 */
	private static void findSemiPalindromes(IRemoteFile root, boolean export) throws RemoteException {
		System.out.println("Searching for semi-palindroms, exportFilter=" + export);
		long t1 = System.currentTimeMillis();
		LinkedList<IRemoteFile> dirs = new LinkedList<IRemoteFile>();
		dirs.add(root);
		SemiPalindromeFilter filter = new SemiPalindromeFilter();
		if (export) {
			System.out.println("Exporting the filter, filter will run as a callback at the client (our VM, slower)");
			UnicastRemoteObject.exportObject(filter);
		} else {
			System.out.println("The filter will run as a callback on the server (remote VM, less communication, faster)");
		}
		while (!dirs.isEmpty()) {
			IRemoteFile dir = dirs.removeLast();
			dirs.addAll(Arrays.asList(dir.listRemoteDirectories()));
			
			IRemoteFile[] files = dir.listByFilter(filter);
			for (int i = 0; i < files.length; i++) {
				System.out.println(files[i].getPath() + " is a has a semi-palindromic file name");
			}
		}
		if (export) {
			UnicastRemoteObject.unexportObject(filter, false);
		}
		long t2 = System.currentTimeMillis();
		System.out.println("Scan took " + (t2-t1) + "ms");
		System.out.println("\n\n");
	}

	/**
	 * Print the first line of remote text files. 
	 */
	private static void printTextFiles(IRemoteFile root) throws IOException {
		System.out.println("Printing the first line of text files.");
		LinkedList<IRemoteFile> dirs = new LinkedList<IRemoteFile>();
		dirs.add(root);
		while (!dirs.isEmpty()) {
			IRemoteFile dir = dirs.removeLast();
			dirs.addAll(Arrays.asList(dir.listRemoteDirectories()));
			
			IRemoteFile[] textFiles = dir.listByRegex("(?i).*\\.txt", false);
			for (int i = 0; i < textFiles.length; i++) {
				printFirstLineOf(textFiles[i]);
			}
		}
	}

	/**
	 * Print the first line of a remote file. This method tries to
	 * handle both Unicode UTF-16 and plain text files. 
	 */
	private static void printFirstLineOf(IRemoteFile file) throws IOException {
		if (!file.isFile() || !file.canRead() || file.isHidden() || file.length() < 5) {
			return;
		}
		IRemoteInputStream remoteInputStream = file.getInputStream();
		RemoteInputStreamWrapper in = new RemoteInputStreamWrapper(remoteInputStream);
		PushbackInputStream pb = new PushbackInputStream(in, 2);
		int b1 = pb.read();
		int b2 = pb.read();
		String charset = null;
		if ((byte)b1 == (byte)0xFF && (byte)b2 == (byte)0xFE) {
			charset = "UTF-16";
		} else {
			charset = Charset.defaultCharset().name();
		}
		pb.unread(b2);
		pb.unread(b1);
		BufferedReader reader = new BufferedReader(new InputStreamReader(pb, charset));
		String line = reader.readLine();
		System.out.println("File " + file.getCanonicalPath() + ": ");
		if (line.length() > 100) {
			line = line.substring(0, 100);
		}
		System.out.println(line);
		System.out.println();
		reader.close();
	}
}
