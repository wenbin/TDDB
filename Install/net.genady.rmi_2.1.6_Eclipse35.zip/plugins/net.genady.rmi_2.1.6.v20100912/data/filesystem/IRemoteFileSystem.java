/*
 * This file is a part of the RMI Plugin for Eclipse tutorials.
 * Copyright (C) 2002-7 Genady Beryozkin
 * 
 * You are free to modify this file, as long as you leave
 * the following copyright:
 * 
 * This file is based on the Remote File System example of
 * the RMI Plug-in for Eclipse. The original code is 
 * Copyright (C) 2002-7 Genady Beryozkin
 */

package demo.rmi.filesystem.common;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * An interface that represents a remote file system.
 * It should be used to retrieve the roots of the remote file system.
 * 
 * @author Genady Beryozkin, rmi-info@genady.net
 */
public interface IRemoteFileSystem extends Remote {

	/**
	 * Return the host name at which the file system is located.
	 */
	public String getHost() throws RemoteException;
	
	/**
	 * Return the list of file system roots of the remote file system.
	 */
	public IRemoteFile[] getRoots() throws RemoteException;
	
	/**
	 * Return a remote file instance for the given path.
	 */
	public IRemoteFile getRemoteFile(String path) throws RemoteException;
}
