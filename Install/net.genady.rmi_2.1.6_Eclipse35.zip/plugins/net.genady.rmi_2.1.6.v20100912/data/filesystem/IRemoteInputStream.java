/*
 * This file is a part of the RMI Plugin for Eclipse tutorials.
 * Copyright (C) 2002-7 Genady Beryozkin
 * 
 * You are free to modify this file, as long as you leave
 * the following copyright:
 * 
 * This file is based on the Remote File System example of
 * the RMI Plug-in for Eclipse. The original code is 
 * Copyright (C) 2002-7 Genady Beryozkin
 */
package demo.rmi.filesystem.common;

import java.io.InputStream;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * This interface defines a remote input stream that can be used
 * to read from an {@link IRemoteFile}. The interface mimics the
 * {@link InputStream} class with a single difference in the
 * {@link #read(int)} method.
 * 
 * @author Genady Beryozkin, rmi-info@genady.net
 */
public interface IRemoteInputStream extends Remote {

	/**
	 * Read a single byte from the stream. Returns -1 on EOF.
	 * @see InputStream#read()
	 */
	public abstract int read() throws RemoteException;
	
	/**
	 * Read <code>count</code> bytes from the stream.
	 * We can't have the same signature as {@link InputStream#read(byte[], int, int)}
	 * because if the array is an argument it won't be copied back to
	 * the client.
	 * 
	 * @param count the maximum number of bytes to read.
	 * @return the data that was read or <code>null</code> if EOF reached.
	 */
	public byte[] read(int count) throws RemoteException;
	
	/**
	 * @see InputStream#skip(long)
	 */
	public long skip(long n) throws RemoteException;
	
	/**
	 * @see InputStream#available()
	 */
	public int available() throws RemoteException;

	/**
	 * @see InputStream#close()
	 */
	public void close() throws RemoteException;
	
	/**
	 * @see InputStream#mark(int)
	 */
	public void mark(int readlimit) throws RemoteException;
	
	/**
	 * @see InputStream#reset()
	 */
	public void reset() throws RemoteException;
	
	/**
	 * @see InputStream#markSupported()
	 */
	public boolean markSupported() throws RemoteException;
}
