/*
 * This file is a part of the RMI Plugin for Eclipse tutorials.
 * Copyright (C) 2002-7 Genady Beryozkin
 * 
 * You are free to modify this file, as long as you leave
 * the following copyright:
 * 
 * This file is based on the Remote File System example of
 * the RMI Plug-in for Eclipse. The original code is 
 * Copyright (C) 2002-7 Genady Beryozkin
 */

package demo.rmi.filesystem.common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 * This interface is used by {@link IRemoteFile#listRemoteFiles()} method
 * 
 * Clients implementing this interface can either export the implementation
 * using {@link UnicastRemoteObject#exportObject(Remote)} and then
 * the server will make callbacks to the client to perform the filtering.
 * This method will be slow! (Every time the server needs to check the file
 * it will make a remote call).
 * 
 * If the implementation's instance is not exported, it will cause the
 * class code to be run on the server which requires some extra caution
 * with client's codebase and raises security considerations (server 
 * running client's code).
 */
public interface IRemoteFilenameFilter extends Remote {

	 boolean accept(IRemoteFile dir, String name) throws RemoteException;
}
