/*
 * This file is a part of the RMI Plugin for Eclipse tutorials.
 * Copyright (C) 2002-7 Genady Beryozkin
 * 
 * You are free to modify this file, as long as you leave
 * the following copyright:
 * 
 * This file is based on the Remote File System example of
 * the RMI Plug-in for Eclipse. The original code is 
 * Copyright (C) 2002-7 Genady Beryozkin
 */

package demo.rmi.filesystem.server;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;

/**
 * A class that binds the file system implementation to the registry.
 * The default registry is on the local machine and the name is "FileServer".
 * It is possible to override this default value by providing a new name
 * as a single argument to the main class (in {@link Naming#bind(String, java.rmi.Remote)}
 * format.
 * 
 * Check <a href="http://www.genady.net/rmi/v20/demos/">the demos page</a>
 * for an example how to run the server and client on different machines.
 * 
 * @author Genady Beryozkin, rmi-info@genady.net
 */
public class FileServer {

	public static void main(String[] args) {
				
		String where = "rmi://localhost/FileServer";
		if (args.length == 1) {
			where = args[0];
		}
		
		// we're enabling remote class loading for IRemoteFile#listRemoteFiles(IRemoteFilenameFilter)
		// and similar.
		System.setSecurityManager(new RMISecurityManager());
		try {
			RemoteFileSystemImpl remoteFS = new RemoteFileSystemImpl();
			Naming.rebind(where, remoteFS);
			System.out.println("The File Server is ready and is located at \"" + where + "\"");
		} catch (Exception e) {
            System.err.println("Something is wrong, can't continue");
            e.printStackTrace();
            System.exit(-1); // can't just return, rmi threads may not exit
		}
	}
}
